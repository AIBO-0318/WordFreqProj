import os
import sys
import urllib.request
import json
import pandas as pd

class NaverNewsCrawler:
    # 클래스 초기화: API 접속 키 설정
    def __init__(self, client_id, client_secret):
        self.client_id = client_id
        self.client_secret = client_secret

    # 네이버 뉴스 API 호출 함수
    def crawlNaverNews(self, keyword, start=1, display=10):
        # 검색어 인코딩 및 URL 생성 (뉴스 검색 API)
        encText = urllib.parse.quote(keyword)
        url = f"https://openapi.naver.com/v1/search/news?query={encText}&start={start}&display={display}"
        
        # API 요청 객체 생성 및 헤더 설정
        request = urllib.request.Request(url)
        request.add_header("X-Naver-Client-Id", self.client_id)
        request.add_header("X-Naver-Client-Secret", self.client_secret)
        
        try:
            # API 호출 및 응답 코드 확인
            response = urllib.request.urlopen(request)
            rescode = response.getcode()
            
            if rescode == 200:
                # 호출 성공 시 JSON 데이터를 파이썬 딕셔너리로 변환하여 반환
                return json.loads(response.read().decode('utf-8'))
            else:
                print(f"Error Code: {rescode}")
                return None
        except Exception as e:
            # 예외 발생 시 에러 메시지 출력
            print(f"API 호출 오류: {e}")
            return None

    # 데이터를 리스트에 통합하는 함수
    def mergeResultToList(self, result_data, merged_list):
        # 결과 데이터 내의 뉴스 아이템들을 리스트에 추가
        if result_data and 'items' in result_data:
            merged_list.extend(result_data['items'])
        return merged_list

    # 리스트 데이터를 CSV 파일로 저장하는 함수
    def saveJSONListToCSV(self, merged_list, csv_filename):
        if not merged_list:
            print("저장할 데이터가 존재하지 않습니다.")
            return
        
        # 데이터프레임 변환 및 CSV 저장 (한글 깨짐 방지 인코딩)
        df = pd.DataFrame(merged_list)
        os.makedirs(os.path.dirname(csv_filename), exist_ok=True)
        df.to_csv(csv_filename, index=False, encoding='utf-8-sig')
        print(f"성공: {csv_filename} 저장 완료")

# --- 메인 실행 코드 ---
if __name__ == "__main__":
    # 1. API 접속 정보 및 검색어 설정
    client_id = "본인의_ID"
    client_secret = "본인의_SECRET"
    keyword = "인공지능"
    
    # 2. 크롤러 객체 생성 및 변수 초기화
    crawler = NaverNewsCrawler(client_id, client_secret)
    merged_list = []
    start = 1
    display = 10

    # 3. 데이터가 없을 때까지 반복 크롤링 (최대 100번 호출 제한 예시)
    while start < 100:
        crawled_data = crawler.crawlNaverNews(keyword, start, display)
        
        # 데이터가 정상적으로 수집된 경우
        if crawled_data and crawled_data.get('items'):
            print(f"진행중: {keyword} [{start}] 크롤링 성공")
            crawler.mergeResultToList(crawled_data, merged_list)
            start += display # 다음 페이지로 이동
        else:
            # 데이터가 없으면 반복문 종료
            print("알림: 더 이상 검색 결과가 없습니다.")
            break
            
    # 4. 결과 저장 및 확인
    result_filename = f"./data/{keyword}_naver_news.csv"
    crawler.saveJSONListToCSV(merged_list, result_filename)
    
    # 저장된 CSV 파일을 데이터프레임으로 다시 로드하여 확인
    df_check = pd.read_csv(result_filename)
    print("\n--- 저장된 데이터 요약 ---")
    print(df_check.head())

    